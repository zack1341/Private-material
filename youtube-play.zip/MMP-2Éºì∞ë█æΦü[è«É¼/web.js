$(function(){
    var playlist = ["nFbrUa2DpMA","QyzK21nx70o","_oAt8PQtRVU","EIw8SO6dadQ","iVuaJjHssYg"];
    var jg = 0;
    $("#control").click(function(){
        console.log("video changed" , player);
        video_num++;
        if(video_num == playlist.length){
            video_num = 0;
        }
        player.loadVideoById(playlist[video_num]);
        if(playlist[video_num] == "Rg3W-lWCgeU"){
            $("#genre").html("我々だop-ed");
        }else if(playlist[video_num] == "Oq9Zl4OB5Qw"){
            $("#genre").html("デリー・みずうみ様");
        }else if(playlist[video_num] == "vB8sxY_PJ_w"){
            $("#genre").html("酔いどれ知らず");
        }else if(playlist[video_num] == "nFbrUa2DpMA"){
            $("#genre").html("作業BGM--BAR--  1");
        }else if(playlist[video_num] == "QyzK21nx70o"){
            $("#genre").html("作業BGM--BAR--  2");
        }else if(playlist[video_num] == "_oAt8PQtRVU"){
            $("#genre").html("作業BGM--BAR--  3");
        }else if(playlist[video_num] == "EIw8SO6dadQ"){
            $("#genre").html("作業BGM--BAR--  4");
        }else if(playlist[video_num] == "iVuaJjHssYg"){
            $("#genre").html("作業BGM--BAR--  5");
        }       
    });

    $("#stop-start").click(function(){
        if(player.getPlayerState() == 2 || player.getPlayerState() == -1){
            player.playVideo();
        }else if(player.getPlayerState() == 1){
            player.pauseVideo();
        }     
    });

    $("#fives").click(function(){
        player.seekTo(player.getCurrentTime() +5);
    });

    $("#tens").click(function(){
        player.seekTo(player.getCurrentTime() +10);
    });

    $("#sixtys").click(function(){
        player.seekTo(player.getCurrentTime() +60);
    });

    $("#five-s").click(function(){
        player.seekTo(player.getCurrentTime() -5);
    });

    $("#ten-s").click(function(){
        player.seekTo(player.getCurrentTime() -10);
    });

    $("#sixty-s").click(function(){
        player.seekTo(player.getCurrentTime() -60);
    });

    $("#controlID").click(function(){
        console.log("changed");
        if(jg==0){
            playlist = ["Rg3W-lWCgeU","Oq9Zl4OB5Qw","vB8sxY_PJ_w"];
            $("#genre").html("我々だop-ed");
            jg++;
            video_num = 0;
            player.loadVideoById(playlist[video_num]);
        }else if(jg==1){
            playlist = ["nFbrUa2DpMA","QyzK21nx70o","_oAt8PQtRVU","EIw8SO6dadQ","iVuaJjHssYg"];
            $("#genre").html("作業BGM--BAR--  1");
            jg=0;
            video_num = 0;
            player.loadVideoById(playlist[video_num]);
        } 
    });

    $("#select").change(function(){
        if($(this).val() == "我々だ"){
            $("#genre").html("我々だop-ed");
            player.loadVideoById("Rg3W-lWCgeU");
        }else if($(this).val() == "デリー・みずうみ様"){
            $("#genre").html("デリー・みずうみ様");
            player.loadVideoById("Oq9Zl4OB5Qw");
        }else if($(this).val() == "酔いどれ知らず"){
            $("#genre").html("酔いどれ知らず");
            player.loadVideoById("vB8sxY_PJ_w");
        }else if($(this).val() == "BAR1"){
            $("#genre").html("作業BGM--BAR--  1");
            player.loadVideoById("nFbrUa2DpMA");
        }else if($(this).val() == "BAR2"){
            $("#genre").html("作業BGM--BAR--  2");
            player.loadVideoById("QyzK21nx70o");
        }else if($(this).val() == "BAR3"){
            $("#genre").html("作業BGM--BAR--  3");
            player.loadVideoById("_oAt8PQtRVU");
        }else if($(this).val() == "BAR4"){
            $("#genre").html("作業BGM--BAR--  4");
            player.loadVideoById("EIw8SO6dadQ");
        }else if($(this).val() == "BAR5"){
            $("#genre").html("作業BGM--BAR--  5");
            player.loadVideoById("iVuaJjHssYg");
        }          
    });

    $("*").keydown(function(e){
        var key = e.key
        console.log(key);
        $("#key").html(key);
        $("#shift").html("Shift: "+e.shiftKey);
        $("#ctrl").html("Ctrl: "+e.ctrlKey);
        $("#alt").html("Alt: "+e.altKey);

        switch(key){
            case " ":
                if(player.getPlayerState() == 2 || player.getPlayerState() == -1){
                    player.playVideo();
                }else if(player.getPlayerState() == 1){
                    player.pauseVideo();
                }
                break;
            case "ArrowUp":
                player.setVolume(player.getVolume() + 1);
                break;
            case "ArrowDown":
                player.setVolume(player.getVolume() - 1);
                break;
            case "ArrowLeft":
                if(e.shiftKey){
                    player.seekTo(player.getCurrentTime() -5);
                }else if(e.altKey){
                    player.seekTo(player.getCurrentTime() -10);
                }else if(e.ctrlKey){
                    player.seekTo(player.getCurrentTime() -60);
                }
                break;
            case "ArrowRight":
                if(e.shiftKey){
                    player.seekTo(player.getCurrentTime() +5);
                }else if(e.altKey){
                    player.seekTo(player.getCurrentTime() +10);
                }else if(e.ctrlKey){
                    player.seekTo(player.getCurrentTime() +60);
                }
                break;
            case "m":
                if(player.isMuted()){
                    player.unMute();
                }else{
                    player.mute();
                }
                break;
        }
    });
});